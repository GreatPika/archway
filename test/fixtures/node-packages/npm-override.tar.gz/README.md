# Real npm valid-override positive

`npm-override` was installed using official npm 11.19.0 on Node 24.21.0 with `--ignore-scripts --no-audit --no-fund --lockfile-version=3`. Registry is https://registry.npmjs.org. No package lifecycle scripts or project hooks ran.

Root package.json declares `dependencies: {"ansi-regex":"6.1.0"}` and `overrides: {"ansi-regex":"$ansi-regex"}`. Real npm accepts the dependency-reference override, and the generated lock v3 records the official ansi-regex 6.1.0 registry instance. The root overrides are not repeated in npm's lockfile: observe package.json when proving the effective source. Expected package classification: external. Compare deliberately stale/contradictory derivatives separately; this is the unchanged real positive install.

Full installed package bytes, index.d.ts, original MIT license, package manifest, both visible and hidden npm locks, minimal source and tsconfig are included. Provenance records the official tarball URL, previously independently verified SRI and SHA256. Package manager command/exit evidence and logs are retained.

`prepare.py` is maintainer-only and performs the official npm install; never call it from runtime assertions. `verify.py` is offline, executes no package code and spawns no subprocesses. Run `python verify.py` from any extracted location. The archive contains no hardlink entries.

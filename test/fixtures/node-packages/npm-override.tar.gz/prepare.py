#!/usr/bin/env python3
"""Maintainer-only official npm override fixture. Never run during checks."""
import json, pathlib, subprocess, os, shutil
ROOT=pathlib.Path(__file__).resolve().parent
NODE_BIN=pathlib.Path('/workspace/shared/toolchains/node-v24.21.0-linux-x64/bin')
BASE=ROOT.parent
folder=ROOT/'npm-override'
folder.mkdir(parents=True,exist_ok=True)
def write(path,obj):
 path.parent.mkdir(parents=True,exist_ok=True)
 path.write_text(json.dumps(obj,indent=2)+'\n' if isinstance(obj,dict) else obj)
write(folder/'package.json',{'name':'archway-npm-override-fixture','version':'1.0.0','private':True,'type':'module','dependencies':{'ansi-regex':'6.1.0'},'overrides':{'ansi-regex':'$ansi-regex'}})
write(folder/'.npmrc','registry=https://registry.npmjs.org\nignore-scripts=true\n')
env=dict(os.environ,PATH=f'{NODE_BIN}:{os.environ["PATH"]}',npm_config_cache=str(BASE/'npm-cache'),npm_config_update_notifier='false')
command=[str(NODE_BIN/'npm'),'install','--ignore-scripts','--no-audit','--no-fund','--lockfile-version=3','--registry=https://registry.npmjs.org']
result=subprocess.run(command,cwd=folder,env=env,text=True,capture_output=True)
write(ROOT/'evidence/install.log',result.stdout+'\n'+result.stderr)
write(ROOT/'evidence/command.json',{'node':'24.21.0','npm':'11.19.0','argv':command,'exitCode':result.returncode,'scriptsDisabled':True})
result.check_returncode()
write(folder/'src/index.ts',"import ansiRegex from 'ansi-regex';\nexport const fixture = ansiRegex();\n")
write(folder/'tsconfig.json',{'compilerOptions':{'module':'NodeNext','moduleResolution':'NodeNext','noEmit':True,'strict':True,'skipLibCheck':True},'include':['src/**/*.ts']})
write(ROOT/'evidence/provenance.json', {'packages': [{'name': 'ansi-regex', 'version': '6.1.0', 'tarball': 'https://registry.npmjs.org/ansi-regex/-/ansi-regex-6.1.0.tgz', 'integrity': 'sha512-7HSX4QQb4CspciLpVFwyRe79O3xsIZDDLER21kERQ71oaPodF8jL725AgJMFAYbooIqolJoRLuM81SpeUkpkvA==', 'sha256': '046f6fe17602b686aa522de193d6046a75e557933365ba51e3e3d8e1fa694f3c', 'license': 'MIT'}]})
print(f'Ready {folder}')

import ansiRegex from 'ansi-regex';
export const fixture = ansiRegex();

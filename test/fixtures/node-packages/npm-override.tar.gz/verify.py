#!/usr/bin/env python3
"""Offline only: inspect prepared files, never install or execute package code."""
import pathlib,json,hashlib
r=pathlib.Path(__file__).resolve().parent;f=r/'npm-override'
manifest=json.loads((f/'package.json').read_text());lock=json.loads((f/'package-lock.json').read_text());installed=json.loads((f/'node_modules/ansi-regex/package.json').read_text())
assert manifest['dependencies']['ansi-regex']=='6.1.0'
assert manifest['overrides']=={'ansi-regex':'$ansi-regex'}
assert lock['lockfileVersion']==3
assert lock['packages']['']['dependencies']=={'ansi-regex':'6.1.0'}
assert lock['packages']['node_modules/ansi-regex']['version']==installed['version']=='6.1.0'
assert installed['name']=='ansi-regex'
assert lock['packages']['node_modules/ansi-regex']['resolved']=='https://registry.npmjs.org/ansi-regex/-/ansi-regex-6.1.0.tgz'
assert (f/'node_modules/ansi-regex/index.d.ts').is_file()
files=[{'path':str(p.relative_to(r)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(f.rglob('*')) if p.is_file()]
(r/'evidence/manifest.json').write_text(json.dumps({'fixture':'npm-override','expected':'external','actualOverride':manifest['overrides'],'files':files},indent=2)+'\n')
print(f'Passed real npm override agreement; {len(files)} retained files verified offline.')

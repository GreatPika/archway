# Real npm and pnpm provenance fixtures for Archway #12

Prepared on 2026-10-11 using Node v24.21.0, npm 11.19.0, and official pnpm 9.15.9. All installs disabled package lifecycle scripts; pnpm additionally used `--ignore-pnpmfile`. Each fixture contains actual package-manager lock/installed metadata, complete installed package files and licenses, a minimal TypeScript entrypoint, and tsconfig. No repository was edited.

## Immediate fixtures

- `npm-ambient-node`: exact official @types/node 24.10.0 and undici-types 7.16.0, plus ansi-regex 6.1.0. The source selects Node ambient types and uses type/value imports from node:fs, require('node:fs'), and require('ansi-regex'); package scripts remain unexecuted.
- `npm-git`: official chalk/ansi-regex repository pinned to registry gitHead f338e1814144efb950276aac84135ff86b72dc8e. Real npm output canonicalized requested git+https to git+ssh in resolved, preserving the exact commit.
- `npm-v3-small`: registry ansi-regex 6.1.0, npm lock v3.
- `npm-v2`: registry ansi-regex 6.1.0, npm lock v2.
- `npm-alias`: fixture-alias is a real npm alias of ansi-regex 6.1.0.
- `npm-tarball`: ansi-regex requested by its official HTTPS tarball URL.
- `npm-shrinkwrap`: actual npm shrinkwrap output; add a conflicting package-lock only in a test derivative to exercise precedence.
- `npm-workspace`: local `packages/local` linked by npm workspace install.
- `npm-file`: `file:../outside-local` copied by npm `--install-links`; actual installed package is a directory inside the fixture. Expected local, not external; actual compiler target is inside root.
- `npm-path`: the same outside source installed as a real symlink. Expected outside-scope local.
- `pnpm-registry`, `pnpm-alias`, `pnpm-tarball`: pnpm lock 9.0/layout 5/isolated manager-produced instances.
- `pnpm-peer`: real @types/react-dom 19.0.4 / @types/react 19.0.12 peer snapshot; installed instance suffix preserves peers.
- `pnpm-hashedpeer`: same dependencies with peers-suffix-max-length=1; actual lock suffix is `jc3r24zgonp253s3uzs32xbkcu`.
- `pnpm-workspace`: link to local `packages/local`.
- `pnpm-injected`: actual copied/injected workspace package. `dedupe-injected-deps=false` prevents pnpm 9 from optimizing matching peer contexts back into an ordinary link. Lock ref is `file:packages/local(ansi-regex@6.1.0)`; .modules.yaml has the injectedDeps mapping.
- `pnpm-file`: copied outside directory source, expected local; target remains inside root.
- `pnpm-path`: real link to `../outside-local`, expected outside-scope local. An ansi-regex dependency ensures pnpm emits .modules.yaml; pnpm emits no .modules.yaml for an all-link-only install.
- `pnpm-moved`: registry package in sibling `pnpm-moved-store`; .modules.yaml records `virtualStoreDir: ../../pnpm-moved-store`, relative to node_modules. Expected external even though physical target is outside fixture root.

Keep `outside-local` and `pnpm-moved-store` as siblings when relocating fixtures. Preserve symlinks. Every referenced package/root exists, and all retained symlinks were checked. The .modules.yaml content is manager-generated and retains its preparation-time storeDir and prunedAt; storeDir is the content-addressed store, not the virtual-store instance mapping.

`npm-v3` is the larger early csstype 3.1.3 fixture. Prefer `npm-v3-small` for committed test data; the early fixture is excluded from the snapshot bundle and offline verification list.

## Verification and provenance

`verify-prepared.mjs` uses the verified local yaml 2.8.1 parser and only filesystem reads plus writing its evidence manifest. It does not spawn subprocesses, fetch, install, or execute package code. It checks 20 expected layouts, aliases and local mappings, validates versions and .d.ts existence, validates layout/lock versions and peer suffixes, and hashes retained files while checking every symlink. This verifies preparation; it is not a claim that Archway's classifier passes.

Run offline:

    /workspace/shared/toolchains/node-v24.21.0-linux-x64/bin/node verify-prepared.mjs

`evidence/prepared-manifest.json` lists exact targets, refs, expected dispositions, file SHA256s and link texts. `evidence/dependency-provenance.json` records official registry URLs, independently recomputed tarball SRI/SHA256 and licenses for all third-party fixture dependencies.

The verified YAML dependency to bundle is `tools/yaml-2.8.1/package` (ISC); keep its LICENSE. Official URL: https://registry.npmjs.org/yaml/-/yaml-2.8.1.tgz. Integrity: sha512-lcYcMxX2PO9XMGvAJkJ3OsNMw+/7FKes7/hgerGUYWIoWu5j/+YQqcZr5JnPZWzOsEBgMbSbiSTn/dv/69Mkpw==. SHA256: 195759b97d3f2e6085474549c069397ad7af6160be6d7c87442b8c47cb724063.

pnpm 9.15.9 is `tools/pnpm-9.15.9/package`, with MIT LICENSE. Official URL: https://registry.npmjs.org/pnpm/-/pnpm-9.15.9.tgz. Integrity: sha512-aARhQYk8ZvrQHAeSMRKOmvuJ74fiaR1p5NQO7iKJiClf1GghgbrlW1hBjDolO95lpQXsfF+UA+zlzDzTfc8lMQ==. SHA256: cf86a7ad764406395d4286a6d09d730711720acc6d93e9dce9ac7ac4dc4a28a7. pnpm is only needed during preparation, never during fixture assertions.

## Maintainer-only preparation

`prepare-fixtures.py` prepares npm fixtures and downloads/verifies/extracts official pnpm and yaml tarballs. `prepare-pnpm.py` prepares pnpm fixtures; `verify-dependency-tarballs.py` downloads/verifies dependency tarballs. `prepare-additional.py` prepares the Node ambient and pinned-Git cases and verifies their dependency tarballs. These four scripts use network and must never be called by check/test code. Preserved lockfiles pin installed instances. For a pristine regeneration, keep the supplied frozen locks or review all changed transitive pins. The official npm registry resolved @types/react's csstype dependency to 3.2.3 at preparation time.

Missing-lock, conflicting alias/version, metadata mutations and conflicting shrinkwrap/package-lock cases should be made as deliberate copies/mutations of these real fixture snapshots in isolated tests. They were not disguised as package-manager-generated contradictory states.

Pinned Git evidence: `evidence/ansi-regex-git-tag.txt` records the official annotated v6.1.0 tag resolving to f338e1814144efb950276aac84135ff86b72dc8e, matching npm registry gitHead and the installed lock.

Pristine preparation order: prepare-fixtures.py, prepare-pnpm.py, verify-dependency-tarballs.py, prepare-additional.py, then the offline verify-prepared.mjs. The first archive prepared-fixtures.tar.gz is immutable and has 18 cases; prepared-fixtures-v2.tar.gz additionally contains Node ambient and pinned-Git cases.

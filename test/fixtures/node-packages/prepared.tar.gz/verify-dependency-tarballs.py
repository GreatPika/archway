#!/usr/bin/env python3
"""Maintainer network-only provenance verification; not used during checks."""
import importlib.util, pathlib, json, hashlib, base64
s=importlib.util.spec_from_file_location('f',pathlib.Path(__file__).with_name('prepare-fixtures.py'));f=importlib.util.module_from_spec(s);s.loader.exec_module(f)
results=[]
for name,version in [('ansi-regex','6.1.0'),('csstype','3.1.3'),('csstype','3.2.3'),('@types/react-dom','19.0.4'),('@types/react','19.0.12')]:
 metadata=json.loads(f.run(f.NPM+['view',f'{name}@{version}','--json','--registry=https://registry.npmjs.org'],f.ROOT/'downloads'))
 pack=json.loads(f.run(f.NPM+['pack',f'{name}@{version}','--ignore-scripts','--json','--registry=https://registry.npmjs.org'],f.ROOT/'downloads'))[0]
 path=f.ROOT/'downloads'/pack['filename']; blob=path.read_bytes()
 integrity='sha512-'+base64.b64encode(hashlib.sha512(blob).digest()).decode()
 assert integrity==metadata['dist']['integrity']
 record={'name':name,'version':version,'tarball':metadata['dist']['tarball'],'integrity':integrity,'sha256':hashlib.sha256(blob).hexdigest(),'license':metadata.get('license'),'local_tarball':str(path)}
 results.append(record)
 print(json.dumps(record),flush=True)
f.write(f.ROOT/'evidence/dependency-provenance.json',{'packages':results})

export declare const localFixture: string;

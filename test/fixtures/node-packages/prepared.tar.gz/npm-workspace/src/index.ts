import { localFixture } from 'archway-local-types';
export { localFixture };

#!/usr/bin/env python3
"""Maintainer-only real pnpm fixture preparation; never called by checks/tests."""
from pathlib import Path
import json, os, sys
from importlib.util import module_from_spec,spec_from_file_location
spec=spec_from_file_location('fixture_common',Path(__file__).with_name('prepare-fixtures.py')); common=module_from_spec(spec); spec.loader.exec_module(common)
ROOT=common.ROOT; write=common.write; run=common.run
common.ENV.update({'XDG_DATA_HOME':str(ROOT/'pnpm-data'),'XDG_CACHE_HOME':str(ROOT/'pnpm-cache'),'XDG_STATE_HOME':str(ROOT/'pnpm-state'),'PNPM_HOME':str(ROOT/'pnpm-home'),'CI':'true'})
PNPM=[str(common.NODE_BIN/'node'),str(ROOT/'tools/pnpm-9.15.9/package/bin/pnpm.cjs')]
def fixture(name,deps,extra=None,config=''):
    folder=ROOT/name
    manifest={'name':f'archway-{name}-fixture','version':'1.0.0','private':True,'type':'module','packageManager':'pnpm@9.15.9','dependencies':deps}
    manifest.update(extra or {})
    write(folder/'package.json',manifest)
    write(folder/'.npmrc','registry=https://registry.npmjs.org\nnode-linker=isolated\nignore-scripts=true\n'+config)
    run(PNPM+['install','--ignore-scripts','--ignore-pnpmfile','--store-dir',str(ROOT/'pnpm-store'),'--reporter=append-only'],folder)
    common.entrypoint(folder,deps)
    print(f'Ready {folder}',flush=True)
    return folder
fixture('pnpm-registry',{'ansi-regex':'6.1.0'})
fixture('pnpm-alias',{'fixture-alias':'npm:ansi-regex@6.1.0'})
fixture('pnpm-tarball',{'ansi-regex':'https://registry.npmjs.org/ansi-regex/-/ansi-regex-6.1.0.tgz'})
fixture('pnpm-peer',{'@types/react-dom':'19.0.4','@types/react':'19.0.12'})
fixture('pnpm-hashedpeer',{'@types/react-dom':'19.0.4','@types/react':'19.0.12'},config='peers-suffix-max-length=1\n')
for name,injected in [('pnpm-workspace',False),('pnpm-injected',True)]:
    folder=ROOT/name
    write(folder/'pnpm-workspace.yaml',"packages:\n  - 'packages/*'\n")
    write(folder/'packages/local/package.json',{'name':'archway-local-types','version':'1.0.0','types':'index.d.ts','peerDependencies':{'ansi-regex':'6.1.0'}})
    write(folder/'packages/local/index.d.ts','export declare const localFixture: string;\n')
    extra={'dependenciesMeta':{'archway-local-types':{'injected':True}}} if injected else {}
    fixture(name,{'archway-local-types':'workspace:*','ansi-regex':'6.1.0'},extra=extra,config='dedupe-injected-deps=false\n' if injected else '')
fixture('pnpm-file',{'archway-outside-types':'file:../outside-local'})
fixture('pnpm-path',{'archway-outside-types':'link:../outside-local','ansi-regex':'6.1.0'})
fixture('pnpm-moved',{'ansi-regex':'6.1.0'},config='virtual-store-dir=../pnpm-moved-store\n')

import type { Stats } from 'node:fs';
import { readFile } from 'node:fs';
export const nodeFs = require('node:fs');
export const ansi = require('ansi-regex');
export type FileStats = Stats;
export { readFile };

import ansiRegex from 'fixture-alias';
export const fixture = ansiRegex();

#!/usr/bin/env python3
"""Maintainer-only Node ambient + official pinned-Git fixture preparation."""
import base64, hashlib, importlib.util, json, pathlib
s=importlib.util.spec_from_file_location('f',pathlib.Path(__file__).with_name('prepare-fixtures.py')); f=importlib.util.module_from_spec(s); s.loader.exec_module(f)
a=f.npm_fixture('npm-ambient-node',{'@types/node':'24.10.0','ansi-regex':'6.1.0'},extra={'type':'commonjs'})
f.write(a/'src/index.ts',"import type { Stats } from 'node:fs';\nimport { readFile } from 'node:fs';\nexport const nodeFs = require('node:fs');\nexport const ansi = require('ansi-regex');\nexport type FileStats = Stats;\nexport { readFile };\n")
f.write(a/'tsconfig.json',{'compilerOptions':{'module':'NodeNext','moduleResolution':'NodeNext','target':'ES2022','strict':True,'noEmit':True,'skipLibCheck':True,'types':['node']},'include':['src/**/*.ts']})
meta=json.loads(f.run(f.NPM+['view','ansi-regex@6.1.0','gitHead','repository','--json','--registry=https://registry.npmjs.org'],f.ROOT/'downloads'))
f.write(f.ROOT/'evidence/ansi-regex-git-source.json',meta)
assert meta['repository']['url']=='git+https://github.com/chalk/ansi-regex.git'
assert meta['gitHead']=='f338e1814144efb950276aac84135ff86b72dc8e'
f.npm_fixture('npm-git',{'ansi-regex':meta['repository']['url']+'#'+meta['gitHead']})
results=json.loads((f.ROOT/'evidence/dependency-provenance.json').read_text())['packages']
for name,version in [('@types/node','24.10.0'),('undici-types','7.16.0')]:
 metadata=json.loads(f.run(f.NPM+['view',f'{name}@{version}','--json','--registry=https://registry.npmjs.org'],f.ROOT/'downloads'))
 pack=json.loads(f.run(f.NPM+['pack',f'{name}@{version}','--ignore-scripts','--json','--registry=https://registry.npmjs.org'],f.ROOT/'downloads'))[0]
 path=f.ROOT/'downloads'/pack['filename']; blob=path.read_bytes()
 integrity='sha512-'+base64.b64encode(hashlib.sha512(blob).digest()).decode()
 assert integrity==metadata['dist']['integrity']
 record={'name':name,'version':version,'tarball':metadata['dist']['tarball'],'integrity':integrity,'sha256':hashlib.sha256(blob).hexdigest(),'license':metadata.get('license'),'local_tarball':str(path)}
 results=[r for r in results if (r['name'],r['version'])!=(name,version)]+[record]
 print(json.dumps(record),flush=True)
f.write(f.ROOT/'evidence/dependency-provenance.json',{'packages':results})

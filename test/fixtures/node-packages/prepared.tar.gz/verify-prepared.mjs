// Offline verification only. Does not spawn a process, install, fetch, or run fixture code.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
const root = path.dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);
const { parse } = require('./tools/yaml-2.8.1/package/dist/index.js');
const readJson = p => JSON.parse(fs.readFileSync(p, 'utf8'));
const readYaml = p => parse(fs.readFileSync(p, 'utf8'));
const cases = [
 ['npm-v3-small', 'ansi-regex', 'external'],
 ['npm-ambient-node', '@types/node', 'external'],
 ['npm-git', 'ansi-regex', 'external'],
 ['npm-v2', 'ansi-regex', 'external'],
 ['npm-alias', 'fixture-alias', 'external'],
 ['npm-tarball', 'ansi-regex', 'external'],
 ['npm-shrinkwrap', 'ansi-regex', 'external'],
 ['npm-workspace', 'archway-local-types', 'local'],
 ['npm-file', 'archway-outside-types', 'local'],
 ['npm-path', 'archway-outside-types', 'outside_scope'],
 ['pnpm-registry', 'ansi-regex', 'external'],
 ['pnpm-alias', 'fixture-alias', 'external'],
 ['pnpm-tarball', 'ansi-regex', 'external'],
 ['pnpm-peer', '@types/react-dom', 'external'],
 ['pnpm-hashedpeer', '@types/react-dom', 'external'],
 ['pnpm-workspace', 'archway-local-types', 'local'],
 ['pnpm-injected', 'archway-local-types', 'local'],
 ['pnpm-file', 'archway-outside-types', 'local'],
 ['pnpm-path', 'archway-outside-types', 'outside_scope'],
 ['pnpm-moved', 'ansi-regex', 'external'],
];
const results=[];
for (const [name, dep, expected] of cases) {
 const dir=path.join(root,name);
 const alias=path.join(dir,'node_modules',dep);
 const target=fs.realpathSync(alias);
 const manifest=readJson(path.join(target,'package.json'));
 const types=path.join(target,manifest.types || manifest.typings || 'index.d.ts');
 assert.ok(fs.statSync(types).isFile(),name);
 const record={name,dependency:dep,expected,manifestName:manifest.name,version:manifest.version,alias:path.relative(root,alias),target:path.relative(root,target),types:path.relative(root,types),link:fs.lstatSync(alias).isSymbolicLink()};
 if(name.startsWith('npm-')) {
   const lockName=name==='npm-shrinkwrap'?'npm-shrinkwrap.json':'package-lock.json';
   const lock=readJson(path.join(dir,lockName));
   assert.equal(lock.lockfileVersion,name==='npm-v2'?2:3);
   assert.ok(lock.packages['node_modules/'+dep],name);
   record.lock=lockName;
   if(name==='npm-git') assert.equal(lock.packages['node_modules/ansi-regex'].resolved,'git+ssh://git@github.com/chalk/ansi-regex.git#f338e1814144efb950276aac84135ff86b72dc8e');
   if(name==='npm-ambient-node') { assert.equal(manifest.version,'24.10.0'); assert.equal(lock.packages['node_modules/undici-types'].version,'7.16.0'); assert.ok(fs.readFileSync(path.join(target,'module.d.ts'),'utf8').includes('require')); }
 } else {
   const lock=readYaml(path.join(dir,'pnpm-lock.yaml'));
   const modules=readYaml(path.join(dir,'node_modules/.modules.yaml'));
   assert.equal(String(lock.lockfileVersion),'9.0');
   assert.equal(modules.layoutVersion,5);
   assert.equal(modules.nodeLinker,'isolated');
   assert.equal(modules.packageManager,'pnpm@9.15.9');
   const snapshot=lock.importers['.'].dependencies[dep].version;
   record.ref=snapshot; record.virtualStoreDir=modules.virtualStoreDir;
   if (name==='pnpm-peer') assert.match(snapshot,/\(@types\/react@19\.0\.12\)$/);
   if (name==='pnpm-hashedpeer') assert.match(snapshot,/\(jc3r24zgonp253s3uzs32xbkcu\)$/);
   if (name==='pnpm-injected') {
     assert.equal(snapshot,'file:packages/local(ansi-regex@6.1.0)');
     assert.ok(modules.injectedDeps['packages/local'].length);
     assert.notEqual(target,fs.realpathSync(path.join(dir,'packages/local')));
   }
   if (name==='pnpm-moved') {
     assert.equal(modules.virtualStoreDir,'../../pnpm-moved-store');
     assert.ok(target.startsWith(path.join(root,'pnpm-moved-store')+path.sep));
   }
 }
 if(name.endsWith('-file')) assert.ok(!record.link || target.includes('/.pnpm/'));
 if(expected==='outside_scope') assert.ok(!target.startsWith(dir+path.sep));
 results.push(record);
}
const visited=[];
function walk(p) {
 for (const entry of fs.readdirSync(p,{withFileTypes:true})) {
   const full=path.join(p,entry.name), relative=path.relative(root,full);
   if(entry.isSymbolicLink()) {
     assert.ok(fs.existsSync(full),`Dangling symlink: ${relative}`);
     visited.push({path:relative,link:fs.readlinkSync(full)});
   } else if(entry.isDirectory()) walk(full);
   else if(entry.isFile()) visited.push({path:relative,sha256:crypto.createHash('sha256').update(fs.readFileSync(full)).digest('hex')});
 }
}
for(const name of [...cases.map(c=>c[0]),'outside-local','pnpm-moved-store']) walk(path.join(root,name));
const result={node:process.version,npm:'11.19.0',pnpm:'9.15.9',cases:results,files:visited};
fs.writeFileSync(path.join(root,'evidence/prepared-manifest.json'),JSON.stringify(result,null,2)+'\n');
console.log(`Verified ${results.length} real manager-prepared fixtures, ${visited.length} retained files/links; all links resolve. No package code, installs, or network executed.`);

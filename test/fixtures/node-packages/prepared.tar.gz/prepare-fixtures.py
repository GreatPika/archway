#!/usr/bin/env python3
"""Maintainer-only fixture preparer. Tests never run this script."""
import base64, hashlib, json, os, pathlib, subprocess, tarfile
ROOT = pathlib.Path(__file__).resolve().parent
NODE_BIN = pathlib.Path('/workspace/shared/toolchains/node-v24.21.0-linux-x64/bin')
ENV = dict(os.environ, PATH=f'{NODE_BIN}:{os.environ["PATH"]}', npm_config_cache=str(ROOT/'npm-cache'), npm_config_update_notifier='false')
NPM = [str(NODE_BIN/'npm')]
def write(path, body):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(body, indent=2)+'\n' if isinstance(body, dict) else body)
def run(args, cwd):
    result=subprocess.run(args,cwd=cwd,env=ENV,text=True,capture_output=True)
    log=ROOT/'evidence'/f'{cwd.name}-{args[0].split("/")[-1]}-{args[1].split("/")[-1]}.log'
    log.parent.mkdir(exist_ok=True)
    with log.open('a') as f: f.write(result.stdout+'\n'+result.stderr)
    result.check_returncode()
    return result.stdout
def entrypoint(folder, dependencies):
    if '@types/react-dom' in dependencies: source = "import type { Root } from 'react-dom/client';\nexport type Fixture = Root;\n"
    elif 'archway-local-types' in dependencies: source = "import { localFixture } from 'archway-local-types';\nexport { localFixture };\n"
    elif 'archway-outside-types' in dependencies: source = "import { outsideFixture } from 'archway-outside-types';\nexport { outsideFixture };\n"
    else: source = "import ansiRegex from '" + ('fixture-alias' if 'fixture-alias' in dependencies else 'ansi-regex') + "';\nexport const fixture = ansiRegex();\n"
    write(folder/'src/index.ts', source)
    write(folder/'tsconfig.json', {'compilerOptions':{'module':'NodeNext','moduleResolution':'NodeNext','strict':True,'noEmit':True,'skipLibCheck':True},'include':['src/**/*.ts']})
def npm_fixture(name, dependencies, lock=3, extra=None, install_links=False):
    folder=ROOT/name
    body={'name':f'archway-{name}-fixture','version':'1.0.0','private':True,'type':'module','dependencies':dependencies}
    body.update(extra or {})
    write(folder/'package.json',body)
    args=NPM+['install','--ignore-scripts','--no-audit','--no-fund',f'--lockfile-version={lock}','--registry=https://registry.npmjs.org']
    if install_links: args+=['--install-links']
    run(args,folder)
    entrypoint(folder,dependencies)
    return folder
if __name__ == '__main__':
    npm_fixture('npm-v3-small',{'ansi-regex':'6.1.0'})
    npm_fixture('npm-v2',{'ansi-regex':'6.1.0'},lock=2)
    npm_fixture('npm-alias',{'fixture-alias':'npm:ansi-regex@6.1.0'})
    npm_fixture('npm-tarball',{'ansi-regex':'https://registry.npmjs.org/ansi-regex/-/ansi-regex-6.1.0.tgz'})
    a=npm_fixture('npm-shrinkwrap',{'ansi-regex':'6.1.0'})
    run(NPM+['shrinkwrap','--ignore-scripts'],a)
    local={'name':'archway-local-types','version':'1.0.0','types':'index.d.ts'}
    write(ROOT/'npm-workspace/packages/local/package.json',local)
    write(ROOT/'npm-workspace/packages/local/index.d.ts','export declare const localFixture: string;\n')
    npm_fixture('npm-workspace',{'archway-local-types':'1.0.0'},extra={'workspaces':['packages/*']})
    write(ROOT/'outside-local/package.json',dict(local,name='archway-outside-types'))
    write(ROOT/'outside-local/index.d.ts','export declare const outsideFixture: string;\n')
    npm_fixture('npm-file',{'archway-outside-types':'file:../outside-local'},install_links=True)
    npm_fixture('npm-path',{'archway-outside-types':'file:../outside-local'})
    for name,version in [('pnpm','9.15.9'),('yaml','2.8.1')]:
        metadata=json.loads(run(NPM+['view',f'{name}@{version}','--json','--registry=https://registry.npmjs.org'],ROOT/'downloads'))
        write(ROOT/'evidence'/f'{name}-{version}-registry-metadata.json',metadata)
        packs=json.loads(run(NPM+['pack',f'{name}@{version}','--ignore-scripts','--json','--registry=https://registry.npmjs.org'],ROOT/'downloads'))
        write(ROOT/'evidence'/f'{name}-{version}-pack.json',{'packs':packs})
        tgz=ROOT/'downloads'/packs[0]['filename']
        sri='sha512-'+base64.b64encode(hashlib.sha512(tgz.read_bytes()).digest()).decode()
        assert sri == metadata['dist']['integrity'], (name,sri,metadata['dist']['integrity'])
        dest=ROOT/'tools'/f'{name}-{version}'
        dest.mkdir(parents=True,exist_ok=True)
        with tarfile.open(tgz,'r:gz') as tar: tar.extractall(dest,filter='data')
        write(ROOT/'evidence'/f'{name}-{version}-verification.json',{'name':name,'version':version,'tarball':metadata['dist']['tarball'],'integrity':sri,'sha256':hashlib.sha256(tgz.read_bytes()).hexdigest(),'license':metadata.get('license'),'extracted_package':str(dest/'package')})
        print(f'Verified {name}@{version}: {dest}/package',flush=True)

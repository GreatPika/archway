// Offline fixture verification: no installs, subprocesses, network, or fixture-code execution.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const {parse}=createRequire(import.meta.url)('./tools/yaml-2.8.1/package/dist/index.js');
const json=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const yaml=p=>parse(fs.readFileSync(p,'utf8'));
const names=['pnpm-root-override','pnpm-git','pnpm-parent-snapshot','pnpm-hashedfilename'];
const records=[];
for(const name of names){
 const dir=path.join(root,name),lock=yaml(path.join(dir,'pnpm-lock.yaml')),modules=yaml(path.join(dir,'node_modules/.modules.yaml'));
 assert.equal(String(lock.lockfileVersion),'9.0');assert.equal(modules.layoutVersion,5);assert.equal(modules.nodeLinker,'isolated');assert.equal(modules.packageManager,'pnpm@9.15.9');
 const dep=name==='pnpm-root-override'?'archway-outside-types':name==='pnpm-git'?'ansi-regex':'@types/react-dom';
 const target=fs.realpathSync(path.join(dir,'node_modules',dep));
 const manifest=json(path.join(target,'package.json'));
 assert.ok(fs.statSync(path.join(target,manifest.types||'index.d.ts')).isFile());
 const ref=lock.importers['.'].dependencies[dep].version;
 records.push({name,dependency:dep,target:path.relative(root,target),ref,packageName:manifest.name,version:manifest.version,virtualStoreDirMaxLength:modules.virtualStoreDirMaxLength});
 if(name==='pnpm-root-override'){
  const rootManifest=json(path.join(dir,'package.json'));
  assert.equal(rootManifest.dependencies[dep],'1.0.0');assert.equal(rootManifest.pnpm.overrides[dep],'file:../outside-local');assert.equal(lock.overrides[dep],'file:../outside-local');
  assert.equal(lock.importers['.'].dependencies[dep].specifier,'file:../outside-local');assert.equal(ref,'file:../outside-local');assert.equal(lock.packages[`${dep}@${ref}`].resolution.directory,'../outside-local');assert.ok(target.startsWith(dir+path.sep));
 }
 if(name==='pnpm-git'){
  const url='https://codeload.github.com/chalk/ansi-regex/tar.gz/f338e1814144efb950276aac84135ff86b72dc8e';assert.equal(ref,url);assert.equal(lock.packages[`ansi-regex@${url}`].resolution.tarball,url);assert.equal(manifest.version,'6.1.0');
 }
 if(name==='pnpm-parent-snapshot'){
  assert.equal(lock.importers['.'].dependencies.csstype,undefined);assert.equal(lock.snapshots['@types/react@19.0.12'].dependencies.csstype,'3.2.3');
  const parent=fs.realpathSync(path.join(dir,'node_modules/@types/react'));
  assert.match(fs.readFileSync(path.join(parent,'index.d.ts'),'utf8'),/import \* as CSS from "csstype"/);
  const child=fs.realpathSync(path.join(parent,'../../csstype'));
  assert.equal(json(path.join(child,'package.json')).version,'3.2.3');records.at(-1).parentSnapshotTarget=path.relative(root,child);
 }
 if(name==='pnpm-hashedfilename'){
  assert.equal(ref,'19.0.4(@types/react@19.0.12)');assert.equal(modules.virtualStoreDirMaxLength,40);assert.ok(target.includes('/@types+react-_nhpha4umwzujnj5z3psgctlogi/'));
 }
}
const files=[];
function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){
 const p=path.join(dir,e.name),rel=path.relative(root,p);
 if(e.isSymbolicLink()){assert.ok(fs.existsSync(p),`Dangling link: ${rel}`);files.push({path:rel,symlink:fs.readlinkSync(p)});}
 else if(e.isDirectory())walk(p);
 else if(e.isFile())files.push({path:rel,sha256:crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex')});
}}
for(const name of [...names,'outside-local'])walk(path.join(root,name));
fs.mkdirSync(path.join(root,'evidence'),{recursive:true});fs.writeFileSync(path.join(root,'evidence/addon-manifest.json'),JSON.stringify({cases:records,files},null,2)+'\n');
console.log(`Verified ${records.length} real fixture cases and ${files.length} retained files/links offline.`);

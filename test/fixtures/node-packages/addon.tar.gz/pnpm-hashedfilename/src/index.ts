import type { Root } from 'react-dom/client';
export type Fixture = Root;

#!/usr/bin/env python3
"""Package regular file bytes independently while preserving symbolic links."""
import pathlib,tarfile,hashlib
r=pathlib.Path(__file__).resolve().parent
names=['pnpm-root-override','pnpm-git','pnpm-parent-snapshot','pnpm-hashedfilename','outside-local','tools/yaml-2.8.1/package','evidence','downloads','README.md','prepare-addon.py','verify-addon.mjs','pack-addon.py']
out=r.parent/'prepared-fixtures-addon.tar.gz'
with tarfile.open(out,'w:gz',dereference=False) as tar:
 for name in names:
  base=r/name
  paths=[base]+(sorted(base.rglob('*')) if base.is_dir() else [])
  for p in paths:
   tar.inodes.clear() # Materialize hardlinked bytes; preserve symlinks.
   info=tar.gettarinfo(str(p),arcname=str(p.relative_to(r)))
   if info.isreg():
    with p.open('rb') as f:tar.addfile(info,f)
   else:tar.addfile(info)
with tarfile.open(out,'r:gz') as tar:
 members=tar.getmembers()
 assert not any(m.islnk() for m in members)
 print(f'{out}: {out.stat().st_size} bytes, {len(members)} members, no tar hardlinks; SHA256 {hashlib.sha256(out.read_bytes()).hexdigest()}')

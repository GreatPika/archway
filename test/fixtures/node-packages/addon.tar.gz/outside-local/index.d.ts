export declare const outsideFixture: string;

#!/usr/bin/env python3
"""Maintainer-only add-on; scripts/hooks disabled. Existing v2 remains unchanged."""
import json, os, pathlib, shutil, subprocess
ROOT=pathlib.Path(__file__).resolve().parent
BASE=ROOT.parent
NODE=pathlib.Path('/workspace/shared/toolchains/node-v24.21.0-linux-x64/bin/node')
PNPM=BASE/'tools/pnpm-9.15.9/package/bin/pnpm.cjs'
ENV=dict(os.environ,PATH=f'{NODE.parent}:{os.environ["PATH"]}',XDG_DATA_HOME=str(BASE/'pnpm-data'),XDG_CACHE_HOME=str(BASE/'pnpm-cache'),XDG_STATE_HOME=str(BASE/'pnpm-state'),PNPM_HOME=str(BASE/'pnpm-home'),CI='true')
def write(p,value):
 p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(json.dumps(value,indent=2)+'\n' if isinstance(value,dict) else value)
def fixture(name,deps,extra=None,config=""):
 folder=ROOT/name
 manifest={'name':f'archway-{name}-fixture','version':'1.0.0','private':True,'type':'module','packageManager':'pnpm@9.15.9','dependencies':deps}
 manifest.update(extra or {})
 write(folder/'package.json',manifest)
 write(folder/'.npmrc','registry=https://registry.npmjs.org\nnode-linker=isolated\nignore-scripts=true\n'+config)
 command=[str(NODE),str(PNPM),'install','--ignore-scripts','--ignore-pnpmfile','--store-dir',str(BASE/'pnpm-store'),'--reporter=append-only']
 result=subprocess.run(command,cwd=folder,env=ENV,text=True,capture_output=True)
 write(ROOT/'evidence'/f'{name}-install.log',result.stdout+'\n'+result.stderr)
 result.check_returncode()
 write(folder/'tsconfig.json',{'compilerOptions':{'module':'NodeNext','moduleResolution':'NodeNext','strict':True,'noEmit':True,'skipLibCheck':True},'include':['src/**/*.ts']})
 print(f'Ready {folder}',flush=True)
 return folder
write(ROOT/'outside-local/package.json',{'name':'archway-outside-types','version':'1.0.0','types':'index.d.ts'})
write(ROOT/'outside-local/index.d.ts','export declare const outsideFixture: string;\n')
a=fixture('pnpm-root-override',{'archway-outside-types':'1.0.0'},{'pnpm':{'overrides':{'archway-outside-types':'file:../outside-local'}}})
write(a/'src/index.ts',"import { outsideFixture } from 'archway-outside-types';\nexport { outsideFixture };\n")
a=fixture('pnpm-git',{'ansi-regex':'git+https://github.com/chalk/ansi-regex.git#f338e1814144efb950276aac84135ff86b72dc8e'})
write(a/'src/index.ts',"import ansiRegex from 'ansi-regex';\nexport const fixture = ansiRegex();\n")
# This is a literal copy of the already manager-prepared peer fixture, no install.
parent=ROOT/'pnpm-parent-snapshot'
if not parent.exists(): shutil.copytree(BASE/'pnpm-peer',parent,symlinks=True)
write(ROOT/'evidence/parent-snapshot.json',{'fixture':'pnpm-parent-snapshot','source':'pnpm-peer (copied prepared fixture; no install)','parentPackage':'@types/react','parentVersion':'19.0.12','parentFile':'node_modules/.pnpm/@types+react@19.0.12/node_modules/@types/react/index.d.ts','dependency':'csstype','parentSnapshotKey':'@types/react@19.0.12','dependencyRef':'3.2.3','dependencyFile':'node_modules/.pnpm/csstype@3.2.3/node_modules/csstype/index.d.ts','reason':'csstype is absent from root importer dependencies and joined through actual @types/react parent snapshot.'})
print(f'Ready {parent}',flush=True)

a=fixture('pnpm-hashedfilename',{'@types/react-dom':'19.0.4','@types/react':'19.0.12'},config='virtual-store-dir-max-length=40\n')
write(a/'src/index.ts',"import type { Root } from 'react-dom/client';\nexport type Fixture = Root;\n")

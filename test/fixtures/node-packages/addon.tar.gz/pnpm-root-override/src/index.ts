import { outsideFixture } from 'archway-outside-types';
export { outsideFixture };
